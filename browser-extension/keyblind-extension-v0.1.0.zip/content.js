// src/patterns.ts
var SECRET_PATTERNS = [
  { name: "OpenAI API Key", regex: /sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,}/g, severity: "critical" },
  { name: "GitHub Token", regex: /gh[pousr]_[A-Za-z0-9_]{36,}/g, severity: "critical" },
  { name: "GitHub PAT (classic)", regex: /ghp_[A-Za-z0-9]{36,}/g, severity: "critical" },
  { name: "AWS Access Key", regex: /AKIA[0-9A-Z]{16}/g, severity: "critical" },
  { name: "AWS Secret Key", regex: /(?<![A-Za-z0-9/+=])[A-Za-z0-9/+=]{40}(?![A-Za-z0-9/+=])/g, severity: "high" },
  { name: "Google API Key", regex: /AIza[0-9A-Za-z_-]{35}/g, severity: "high" },
  { name: "Stripe Secret Key", regex: /sk_live_[0-9a-zA-Z]{24,}/g, severity: "critical" },
  { name: "Stripe Publishable Key", regex: /pk_(?:live|test)_[0-9a-zA-Z]{24,}/g, severity: "medium" },
  { name: "Slack Webhook", regex: /https:\/\/hooks\.slack\.com\/services\/[A-Za-z0-9/]+/g, severity: "high" },
  { name: "JWT Token", regex: /eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/g, severity: "high" },
  { name: "Generic API Key", regex: /(?:api[_-]?key|apikey|secret|token|password|access[_-]?token)\s*[:=]\s*['"]([^'"]{8,})['"]/gi, severity: "high" },
  { name: "Private Key (PEM)", regex: /-----BEGIN (?:RSA|EC|DSA|OPENSSH|PGP) PRIVATE KEY-----/g, severity: "critical" },
  { name: ".env Assignment", regex: /^[A-Z_][A-Z0-9_]{0,50}=.{4,}$/gm, severity: "high" }
];
var AI_CHAT_DOMAINS = [
  "claude.ai",
  "chat.openai.com",
  "chatgpt.com",
  "githubcopilot.com",
  "cursor.sh",
  "gemini.google.com",
  "poe.com",
  "perplexity.ai",
  "you.com"
];
function matchSecrets(text) {
  const results = [];
  for (const pattern of SECRET_PATTERNS) {
    let match;
    pattern.regex.lastIndex = 0;
    while ((match = pattern.regex.exec(text)) !== null) {
      results.push({
        pattern: pattern.name,
        match: match[0].slice(0, 8) + "..." + match[0].slice(-4),
        position: { line: 0, col: match.index },
        element: ""
      });
    }
  }
  return results;
}

// src/content.ts
var state = {
  enabled: true,
  pasteInterception: true,
  highlightSecrets: true,
  monitoredSites: []
};
chrome.storage.local.get(["keyblind_state"], (result) => {
  if (result.keyblind_state) {
    state = { ...state, ...result.keyblind_state };
  }
});
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "updateState") {
    state = { ...state, ...msg.state };
  }
});
function scanPage() {
  if (!state.enabled) return [];
  const textNodes = [];
  const walker = document.createTreeWalker(
    document.body,
    NodeFilter.SHOW_TEXT,
    {
      acceptNode(node2) {
        const parent = node2.parentElement;
        if (!parent) return NodeFilter.FILTER_REJECT;
        const tag = parent.tagName.toLowerCase();
        if (["script", "style", "noscript", "input", "textarea", "select"].includes(tag)) {
          return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      }
    }
  );
  let node;
  while (node = walker.nextNode()) {
    if (node.textContent && node.textContent.trim()) {
      textNodes.push({ node, parent: node.parentElement });
    }
  }
  const allSecrets = [];
  for (const { node: node2, parent } of textNodes) {
    const secrets = matchSecrets(node2.textContent || "");
    for (const s of secrets) {
      s.element = getCSSPath(parent);
      allSecrets.push(s);
    }
  }
  return allSecrets;
}
function getCSSPath(el) {
  const path = [];
  let current = el;
  while (current && current !== document.body) {
    let selector = current.tagName.toLowerCase();
    if (current.id) {
      selector = "#" + current.id;
      path.unshift(selector);
      break;
    }
    if (current.className && typeof current.className === "string") {
      const classes = current.className.trim().split(/\s+/).slice(0, 2);
      if (classes.length) selector += "." + classes.join(".");
    }
    path.unshift(selector);
    current = current.parentElement;
  }
  return path.join(" > ");
}
function addWarningBanner(secrets) {
  if (document.getElementById("keyblind-warning")) return;
  const banner = document.createElement("div");
  banner.id = "keyblind-warning";
  banner.style.cssText = `
    position: fixed; top: 0; left: 0; right: 0; z-index: 999999;
    background: linear-gradient(135deg, #dc2626, #991b1b);
    color: white; padding: 10px 16px; font-family: system-ui, sans-serif;
    font-size: 14px; display: flex; align-items: center; justify-content: space-between;
    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
  `;
  banner.innerHTML = `
    <span>Keyblind detected ${secrets.length} secret(s) on this page \u2014 be careful sharing or screenshotting.</span>
    <button id="keyblind-dismiss" style="background:rgba(255,255,255,0.2);border:none;color:white;padding:4px 12px;border-radius:4px;cursor:pointer;font-size:13px">Dismiss</button>
  `;
  document.body.prepend(banner);
  banner.querySelector("#keyblind-dismiss")?.addEventListener("click", () => banner.remove());
}
function interceptPasteEvent(e) {
  if (!state.enabled || !state.pasteInterception) return;
  const hostname = window.location.hostname;
  const isAIChat = AI_CHAT_DOMAINS.some((d) => hostname.includes(d));
  if (!isAIChat) return;
  const clipboardData = e.clipboardData;
  if (!clipboardData) return;
  const text = clipboardData.getData("text/plain");
  if (!text) return;
  const secrets = matchSecrets(text);
  if (secrets.length === 0) return;
  let sanitized = text;
  for (const pattern of SECRET_PATTERNS) {
    sanitized = sanitized.replaceAll(pattern.regex, (match) => {
      const label = pattern.name.toUpperCase().replace(/\s+/g, "_");
      return `[KEYBLIND_${label}_${match.slice(0, 4)}...${match.slice(-4)}]`;
    });
  }
  e.preventDefault();
  const target = e.target;
  if (target.isContentEditable || target.tagName === "TEXTAREA" || target.tagName === "INPUT") {
    document.execCommand("insertText", false, sanitized);
  }
  showToast(`${secrets.length} secret(s) intercepted and sanitized`);
}
function showToast(message) {
  const toast = document.createElement("div");
  toast.style.cssText = `
    position: fixed; bottom: 20px; right: 20px; z-index: 9999999;
    background: #1a1a2e; color: #58a6ff; border: 1px solid #30363d;
    padding: 10px 16px; border-radius: 8px; font-family: system-ui, sans-serif;
    font-size: 13px; box-shadow: 0 4px 12px rgba(0,0,0,0.4);
    animation: keyblind-fade-in 0.3s ease;
  `;
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transition = "opacity 0.3s";
    setTimeout(() => toast.remove(), 300);
  }, 3e3);
}
var scanTimeout;
var observer = new MutationObserver(() => {
  if (!state.enabled) return;
  clearTimeout(scanTimeout);
  scanTimeout = window.setTimeout(() => {
    const secrets = scanPage();
    if (secrets.length > 0) {
      addWarningBanner(secrets);
      if (state.highlightSecrets) highlightSecrets(secrets);
    }
  }, 500);
});
function highlightSecrets(secrets) {
  document.querySelectorAll(".keyblind-highlight").forEach((el) => {
    const parent = el.parentNode;
    if (parent) {
      parent.replaceChild(document.createTextNode(el.textContent || ""), el);
      parent.normalize();
    }
  });
  for (const secret of secrets.slice(0, 20)) {
    try {
      const el = document.querySelector(secret.element);
      if (el && el.textContent) {
        const span = document.createElement("span");
        span.className = "keyblind-highlight";
        span.style.cssText = "background:rgba(220,38,38,0.3);border-bottom:2px wavy #dc2626;padding:1px 2px;border-radius:2px";
        span.textContent = el.textContent.slice(secret.position.col, secret.position.col + 20);
        span.title = `Keyblind: ${secret.pattern} detected`;
        el.replaceChild(span, el.firstChild);
      }
    } catch {
    }
  }
}
document.addEventListener("DOMContentLoaded", () => {
  if (!state.enabled) return;
  observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  const secrets = scanPage();
  if (secrets.length > 0) {
    addWarningBanner(secrets);
  }
});
document.addEventListener("paste", interceptPasteEvent, true);
var style = document.createElement("style");
style.textContent = `
  @keyframes keyblind-fade-in {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .keyblind-highlight {
    cursor: help;
  }
`;
document.head.appendChild(style);
